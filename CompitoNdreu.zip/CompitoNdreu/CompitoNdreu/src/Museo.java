public class Museo {

    private String nome;

     public Museo(String nome){
     
        this.nome=nome;


     }

    public void entra(){

        System.out.println(Thread.currentThread().getName()+"   " +    "     è entrato nel museo");

    }
    


    public void esci(){

        System.out.println(Thread.currentThread().getName()+"     " +"      è uscito dal museo");


    }
}
