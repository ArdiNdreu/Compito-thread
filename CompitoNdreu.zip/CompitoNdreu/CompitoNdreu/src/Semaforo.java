public class Semaforo {
    

    private int valore;


    public Semaforo(int valore){

        this.valore=valore;

    }


    public synchronized void p(){
     
        while(valore==0){

          System.out.println(Thread.currentThread().getName()+"         sto aspettando per entrare al museo");

        try{
  
            wait();

        }catch(Exception e){
      
            e.printStackTrace();

        }

        

        }
       
        valore--;
    }

    public synchronized void v(){
      
        notifyAll();
        valore++;
    }
}
