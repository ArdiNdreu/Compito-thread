public class Turista  extends Thread{


    /**
     *
     */
    private Semaforo s;
    /**
     *
     */
    private Museo m;
    /**
     *
     */
    private String nome;


    /**
     * @param s
     * @param m
     * @param nome
     */
    public Turista(Semaforo s,Museo m,String nome){

        this.s=s;
        this.m=m;
        this.nome=nome;
        setName(nome);

    }

    

    @Override
    public void run(){
   
        int visita=(int) (Math.random()*1000+100);
  
        s.p();
        m.entra();
         try{
            sleep(visita);
        }catch(Exception e){

            e.printStackTrace();
        }
        m.esci();
        s.v();

    }

    
}
