public class App {
    public static void main(String[] args) throws Exception {

        Semaforo s=new Semaforo(3);
        Museo m=new Museo("uffizzi");
        Turista t=new Turista(s,m,"giorgio");
        Turista t1=new Turista(s,m,"giovanni");
        Turista t2=new Turista(s,m,"leonard");
        Turista t3=new Turista(s,m,"federico");
        Turista t4=new Turista(s,m,"selena");
        Turista t5=new Turista(s,m,"milena");
        Turista t6=new Turista(s,m,"Samuela");
        Turista t7=new Turista(s,m,"artesia");

    
        t.start();
        t1.start();
        t2.start();
        t3.start();
        t4.start();
        t5.start();
        t6.start();
        t7.start();

        t.join();
        t1.join();
        t2.join();
        t3.join();
        t4.join();
        t5.join();
        t6.join();
        t7.join();

    
    }
}
